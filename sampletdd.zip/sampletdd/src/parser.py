def resolve_properties(application_properties, environment_properties, xml_files):
    resolved_properties = {}
    missing_properties = {}

    for key, value in application_properties.items():
        if value.startswith('${'):
            ref_key = value[2:-1]  # Extract the key within ${}
            found = False
            
            # Check in XML files
            for xml_name, xml_root in xml_files.items():
                element = xml_root.find(f".//*[name='{ref_key}']")
                if element is not None:
                    resolved_properties[key] = element.find('value').text
                    found = True
                    break
                    
            # Check in environment properties
            if not found:
                if ref_key in environment_properties:
                    resolved_properties[key] = environment_properties[ref_key]
                    found = True

            # Log missing properties
            if not found:
                missing_properties[key] = value

        else:
            resolved_properties[key] = value
    
    return resolved_properties, missing_properties