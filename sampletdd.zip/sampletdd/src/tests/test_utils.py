
import os
from src.utils import output_properties, log_missing_properties

def test_output_properties_console(capfd):
    properties = {"mq.jcbc.sessionCacheSize": "1", "jCBC_kafka_log_lingerMs": "20"}
    output_properties(1, properties)
    
    out, err = capfd.readouterr()
    assert "mq.jcbc.sessionCacheSize: 1" in out
    #assert "key2: value2" in out

def test_output_properties_file(tmpdir):
    properties = {"mq.jcbc.sessionCacheSize": "1", "jCBC_kafka_log_lingerMs": "20"}
    output_file = tmpdir.join("output_properties.properties")
    
    output_properties(2, properties)
    
    assert os.path.exists('output_properties.properties')
    with open('output_properties.properties', 'r') as f:
        content = f.read()
        assert "mq.jcbc.sessionCacheSize = 1" in content
        #assert "jCBC_kafka_log_lingerMs = 20" in content

def test_log_missing_properties():
    file_path = "C:\\Users\\G88729\\Desktop\\sampletdd\\src\\tests\\test_data\\application.properties"
    missing_properties = {"mq.jcbc.sessionCacheSize": "1"}
    log_file = file_path.join("missing_properties.log")
    
    log_missing_properties(missing_properties)
    
    assert os.path.exists('missing_properties.log')
    with open('missing_properties.log', 'r') as f:
        content = f.read()
        assert "mq.jcbc.sessionCacheSize = 1" in content
        assert "jCBC_kafka_log_lingerMs = 20" in content
