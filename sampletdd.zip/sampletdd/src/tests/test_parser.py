
import os
from src.parser import resolve_properties
from src.config import read_properties_file, load_xml_files

def properties():
    file_path="C:\\Users\\G88729\\Desktop\\sampletdd\\src\\tests\\test_data\\application.properties"
    return read_properties_file(file_path)


def xml_files():
    file_dir="C:\\Users\\G88729\\Desktop\\sampletdd\\src\\tests\\test_data"
    return load_xml_files(file_dir)

def resolve_properties(properties, xml_files):
    problems =resolve_properties(properties, xml_files)
    assert problems == []  # Assuming no problems
    assert 'some.property' in properties
    assert properties['jCBC_Kafka_MaxPoll_Interval'] == '2147483647'  # Adjust based on actual expected value
